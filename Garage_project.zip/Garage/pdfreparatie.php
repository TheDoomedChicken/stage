<?php
session_start();
include 'side-job/config.php';


$SAfspraaktijd = $_SESSION['date'];


$Email = $_SESSION['Email'];
$Prijs = 140;

$datum = date("Y-m-d");

    $sql = "SELECT * FROM klant WHERE Email='$Email';";
    $result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {


    $klant = $row['ID'];
    $naam = $row['voornaam'];
    $achternaam = $row['achternaam'];
    $adres = $row['adres'];
    $plaats = $row['plaats'];
    $postcode = $row['postcode'];
    $telefoon = $row['mobielnum'];
    $Email = $row['Email'];
    $huisnummer = $row['huisnummer'];
    $merk = $row['merk'];
    $model = $row['model'];
    $kenteken = $row['kenteken'];

    }
}


require("fpdf181/fpdf.php");




$pdf = new FPDF("p","mm","A4");

$pdf->Addpage();

define('EURO',chr(128));

$pdf->Setfont('Arial','B',14);

$pdf->Cell(130,5, "Factuur Reparatie",0,0);
$pdf->Cell(59,5,'',0,1);
$pdf->Cell(130,5, "",0,0);
$pdf->Cell(59,5,'',0,1);

$pdf->Setfont('Arial','B',10);

$pdf->Cell(130,5, "Klant",0,0);
$pdf->Cell(59,5,'',0,1);

$pdf->Setfont('Arial','B',9);

$pdf->Cell(130,5, "",0,0);
$pdf->Cell(59,5,'',0,1);
$pdf->Cell(130,5, "$naam $achternaam",0,0);
$pdf->Cell(59,5,'',0,1);
$pdf->Cell(130,5, "$adres $huisnummer",0,0);
$pdf->Cell(59,5,'',0,1);
$pdf->Cell(130,5, "$postcode $plaats",0,0);
$pdf->Cell(59,5,'',0,1);
$pdf->Cell(0.1,5, "",0,0);
$pdf->Cell(59,5,'',0,1);
$pdf->Cell(130,5, "Locatie",0,0);
$pdf->Cell(59,5,'',0,1);
$pdf->Cell(59,5,'Autobedrijf Snelstart',0,1);
$pdf->Cell(0.1,5, "",0,0);
$pdf->Cell(59,5,'Adres : Arena 301',0,1);
$pdf->Cell(0.1,5, "",0,0);
$pdf->Cell(59,5,'1403AZ Hilversum',0,1);
$pdf->Cell(59,5,'',0,1);
$pdf->Cell(130,5, "$kenteken",0,0);
$pdf->Cell(59,5,'',0,1);
$pdf->Cell(130,5, "$merk",0,0);
$pdf->Cell(59,5,'',0,1);
$pdf->Cell(130,5, "$model",0,0);
$pdf->Cell(59,5,'',0,1);
$pdf->Cell(59,5,'',0,1);
$pdf->Cell(130,5, "Klantnr $klant",0,0);
$pdf->Cell(59,5,'',0,1);
$pdf->Cell(130,5, "Factuur 249892",0,0);
$pdf->Cell(59,5,'',0,1);
$pdf->Cell(130,5, "Factuur datum $datum",0,0);
$pdf->Cell(59,5,'',0,1);
$pdf->Cell(130,5, "Afspraak datum $SAfspraaktijd",0,0);
$pdf->Cell(130,5, "",0,0);
$pdf->Cell(59,5,'',0,1);

//Regel 1 factuur

$pdf->Cell(170 ,5,"totaal",1,1);

//Regel 2 factuur














$pdf->Cell(170 ,5,EURO.$Prijs,1,0);










$pdf->Output();
