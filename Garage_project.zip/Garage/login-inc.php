<?php


require_once 'side-job/config.php';


$username = $password = "";
$username_err = $password_err = "";


if($_SERVER["REQUEST_METHOD"] == "POST"){


    if(empty(trim($_POST["Email"]))){
       ;
    } else{
        $username = trim($_POST["Email"]);
    }


    if(empty(trim($_POST['wachtwoord']))){
     ;
    } else{
        $password = trim($_POST['wachtwoord']);
    }


    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT Email, Wachtwoord FROM klant WHERE Email = ?";
        if($stmt = mysqli_prepare($conn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);

            // Set parameters
            $param_username = $username;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);

                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $username, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                             $cookie_name = "user";
                $cookie_value = $username;
                setcookie($cookie_name, $cookie_value, time() + (86400), "/"); // 86400 = 1 day
                                session_start();
                                $_SESSION['Email'] = $username;

                            header("Location: http://localhost/Garage/index2.php");
                        } else{
                            header("Location: http://localhost/Garage/fout_wachtwoord_klant.php");
                        }
                    }
                }
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($conn);
}
?>
<html>
<body>
<p>Incorect mail adress</p><br>
<a href="login.php">klik hier</a>
</body>
</html>
