<?php
include_once ('../side-job/config.php') ;

// defines all the srings of the POSTED information
$naam = mysqli_real_escape_string($conn, $_REQUEST['voornaam']);
$achternaam = mysqli_real_escape_string($conn, $_REQUEST['achternaam']);
$adres = mysqli_real_escape_string($conn, $_REQUEST['adres']);
$postcode = mysqli_real_escape_string($conn, $_REQUEST['postcode']);
$plaats = mysqli_real_escape_string($conn, $_REQUEST['plaats']);
$telefoon = mysqli_real_escape_string($conn, $_REQUEST['mobielnum']);
$email = mysqli_real_escape_string($conn, $_REQUEST['Email']);
$huisnummer = mysqli_real_escape_string($conn, $_REQUEST['huisnummer']);
$wachtwoord = mysqli_real_escape_string($conn, $_REQUEST['wachtwoord']);
$merk = mysqli_real_escape_string($conn, $_REQUEST['merk']);
$model = mysqli_real_escape_string($conn, $_REQUEST['model']);
$kenteken = mysqli_real_escape_string($conn, $_REQUEST['kenteken']);

$hash = password_hash($wachtwoord, PASSWORD_DEFAULT);



$sql = "INSERT INTO klant (voornaam, achternaam, adres, postcode, plaats, mobielnum, Email, huisnummer, wachtwoord, merk, model, kenteken) VALUES ('$naam', '$achternaam', '$adres','$postcode','$plaats','$telefoon','$email','$huisnummer','$hash','$merk','$model','$kenteken')";
if(mysqli_query($conn, $sql)){
    header("Location: http://localhost/garage/login.php");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
    echo 'help';
}
// above it connects to the database and if it fails it kicks back an error message
mysqli_close($conn);
?>
