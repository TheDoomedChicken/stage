<?php
include_once ('config.php') ;
session_start();

$email = $_SESSION['Email'];
$query = "SELECT ID FROM klant WHERE Email = '".$email."'";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $klantid = $row["ID"];
    }
} else {
    echo "0 results";
}
//aantal admins
$adquery = "SELECT adID FROM admin";
$adstmt = mysqli_query($conn, $adquery);
$adaantal = mysqli_num_rows($adstmt);
//aantal admins - 1 voor de loop
$adaantal2 = $adaantal - 1;

// werkuur
$start = mysqli_real_escape_string($conn, $_POST['start_tijd']);
// aangegeven datum
$date = mysqli_real_escape_string($conn, $_POST['date']);
//soort
$soort = "Reparatie";
//sessie voor datum
$_SESSION['date'] = $date;

//begin tijd
$begin_tijd = 480;
//tijd
$tijd = 60;

for($x = 1; $x <= $adaantal; $x ++){
$query = "SELECT ID FROM afspraak WHERE datum = '".$date."'";
$stmt = mysqli_query($conn, $query);
if(mysqli_num_rows($stmt) !== 0){
    //detecteerd wel de datum
    if($start == "1"){
    $query2 = "SELECT ID FROM afspraak WHERE datum = '".$date."' AND werkuur >= 1 AND werkuur <= 4 AND ad_ID = '".$x."'";
    $stmt2 = mysqli_query($conn, $query2);
    if(mysqli_num_rows($stmt2) !== 0){
        //datum en tijd al in beslag genomen
        header("Location: http://localhost/Garage/No-space.php?error=tijd");
    } elseif (mysqli_num_rows($stmt2) == 0){
        //datum gedetecteerd maar geen tijd
        $query3 = "INSERT INTO afspraak (ID, datum, werkuur, ad_ID, soort) VALUES ('".$klantid."', '".$date."', '".$start."', '".$x."', '".$soort."')";
        mysqli_query($conn, $query3);
        $start ++;
        $query4 = "INSERT INTO afspraak (ID, datum, werkuur, ad_ID, soort) VALUES ('".$klantid."', '".$date."', '".$start."', '".$x."', '".$soort."')";
        mysqli_query($conn, $query4);
        $start ++;
        $query5 = "INSERT INTO afspraak (ID, datum, werkuur, ad_ID, soort) VALUES ('".$klantid."', '".$date."', '".$start."', '".$x."', '".$soort."')";
        mysqli_query($conn, $query5);
        $start ++;
        $query6 = "INSERT INTO afspraak (ID, datum, werkuur, ad_ID, soort) VALUES ('".$klantid."', '".$date."', '".$start."', '".$x."', '".$soort."')";
        mysqli_query($conn, $query6);
        header("Location: http://localhost/Garage/pdfreparatie.php?success=tijd");
        break;
    }
    } elseif ($start == "5"){
        $query4 = "SELECT ID FROM afspraak WHERE datum = '".$date."' AND werkuur >= '5' AND werkuur <= '8' AND ad_ID = '".$x."'";
        $stmt4 = mysqli_query($conn, $query4);
    if(mysqli_num_rows($stmt4) !== 0){
        //datum en tijd al in beslag genomen
        header("Location: http://localhost/Garage/No-space.php?error=tijd1");
    } elseif (mysqli_num_rows($stmt4) == 0){
        //datum gedetecteerd maar geen tijd
        $query5 = "INSERT INTO afspraak (ID, datum, werkuur, ad_ID, soort) VALUES ('".$klantid."', '".$date."', '".$start."', '".$x."', '".$soort."')";
        mysqli_query($conn, $query5);
        $start ++;
        $query6 = "INSERT INTO afspraak (ID, datum, werkuur, ad_ID, soort) VALUES ('".$klantid."', '".$date."', '".$start."', '".$x."', '".$soort."')";
        mysqli_query($conn, $query6);
        $start ++;
        $query7 = "INSERT INTO afspraak (ID, datum, werkuur, ad_ID, soort) VALUES ('".$klantid."', '".$date."', '".$start."', '".$x."', '".$soort."')";
        mysqli_query($conn, $query7);
        $start ++;
        $query7 = "INSERT INTO afspraak (ID, datum, werkuur, ad_ID, soort) VALUES ('".$klantid."', '".$date."', '".$start."', '".$x."', '".$soort."')";
        mysqli_query($conn, $query7);
        header("Location: http://localhost/Garage/pdfreparatie.php?success=tijd1");
        break;
    }
    }
} elseif (mysqli_num_rows($stmt) == 0){
    //detecteert niet de datum
    $query6 = "INSERT INTO afspraak (ID, datum, werkuur, ad_ID, soort) VALUES ('".$klantid."', '".$date."', '".$start."', '".$x."', '".$soort."')";
    mysqli_query($conn, $query6);
    $start ++;
    $query7 = "INSERT INTO afspraak (ID, datum, werkuur, ad_ID, soort) VALUES ('".$klantid."', '".$date."', '".$start."', '".$x."', '".$soort."')";
    mysqli_query($conn, $query7);
    $start ++;
    $query8 = "INSERT INTO afspraak (ID, datum, werkuur, ad_ID, soort) VALUES ('".$klantid."', '".$date."', '".$start."', '".$x."', '".$soort."')";
    mysqli_query($conn, $query8);
    $start ++;
    $query9 = "INSERT INTO afspraak (ID, datum, werkuur, ad_ID, soort) VALUES ('".$klantid."', '".$date."', '".$start."', '".$x."', '".$soort."')";
    mysqli_query($conn, $query9);
    header("Location: http://localhost/Garage/pdfreparatie.php?success=datum1");
    break;
} else {
    echo "0 results";
}
}

      


?>
