<?php
include_once ('../side-job/config.php') ;
session_start();

$email = $_SESSION['Email'];
$query = "SELECT ID FROM klant WHERE Email = '".$email."'";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $klantid = $row["ID"];
    }
} else {
    echo "0 results";
}
//aantal admins
$adquery = "SELECT adID FROM admin";
$adstmt = mysqli_query($conn, $adquery);
$adaantal = mysqli_num_rows($adstmt);
//aantal admins - 1 voor de loop
$adaantal2 = $adaantal - 1;

// werkuur
$start = mysqli_real_escape_string($conn, $_POST['start_tijd']);
// aangegeven datum
$date = mysqli_real_escape_string($conn, $_POST['date']);
//soort
$soort = "Service";
$_SESSION['date'] = $date;

//begin tijd
$begin_tijd = 480;
//tijd
$tijd = 60;

for($x = 1; $x <= $adaantal; $x ++){
$query = "SELECT ID FROM afspraak WHERE datum = '".$date."'";
$stmt = mysqli_query($conn, $query);
if(mysqli_num_rows($stmt) !== 0){
    //detecteerd wel de datum
    $query2 = "SELECT ID FROM afspraak WHERE datum = '".$date."' AND werkuur = '".$start."' AND ad_ID = '".$x."'";
    $stmt2 = mysqli_query($conn, $query2);
    if(mysqli_num_rows($stmt2) !== 0){
        //datum en tijd al in beslag genomen
        header("Location: http://localhost/Garage/No-space.php?error=tijd");
    } elseif (mysqli_num_rows($stmt2) == 0){
            //datum gedetecteerd maar geen tijd
            $query3 = "INSERT INTO afspraak (ID, datum, werkuur, ad_ID, soort) VALUES ('".$klantid."', '".$date."', '".$start."', '".$x."', '".$soort."')";
            mysqli_query($conn, $query3);
            header("Location: http://localhost/Garage/pdfservice.php?success=tijd");

            break;
            } else {
        echo "fuckyou";
    }
} elseif (mysqli_num_rows($stmt) == 0){
    //detecteert niet de datum
    $query4 = "INSERT INTO afspraak (ID, datum, werkuur, ad_ID, soort) VALUES ('".$klantid."', '".$date."', '".$start."', '".$x."', '".$soort."')";
    mysqli_query($conn, $query4);
    header("Location: http://localhost/Garage/pdfservice.php?success=datum");
    break;
} else {
    echo "0 results";
}
}




?>
