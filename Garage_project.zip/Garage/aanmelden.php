<?php
   session_start();
?>

<!DOCTYPE html>
<html>
	<head>
		
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
                <meta name="description" content="Demo project">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<style type="text/css"></style>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>

    </head>

    <body>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="index.php">
    <img src="images/about-logo.png" alt="logo" style="width:40px;">
  </a>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="werknemers.php">Werknemers</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="login.php">Login</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="aanmelden.php">Aanmelden</a>
    </li>
  </ul>
</nav>

<!--this is where the page content goes-->

<form class="Invoeren" action="side-job/verwerk.php" method="POST">
        <center>
        <input required type="text" id="voornaam" name="voornaam" placeholder="Voornaam"><br>
        <input required type="text" id="achternaam" name="achternaam" placeholder="Achternaam"><br>
        <input required type="text" id="adres" name="adres" placeholder="Adres"><br>
        <input required type="text" id="postcode" name="postcode" placeholder="Postcode"><br>
        <input required type="text" id="plaats" name="plaats" placeholder="Plaats"><br>
        <input required type="text" id="huisnummer" name="huisnummer" placeholder="Huisnummer"><br>
        <input required type="text" id="mobielnum" name="mobielnum" placeholder="Telefoon-nummer"><br>
        <input required type="email" id="Email" name="Email" placeholder="Email"><br>
        <input required type="text" id="merk" name="merk" placeholder="Merk"><br>
        <input required type="text" id="model" name="model" placeholder="Model"><br>
        <input required type="text" id="kenteken" name="kenteken" placeholder="Kenteken"><br>
        <input required type="password" id="wachtwoord" name="wachtwoord" placeholder="Wacthwoord"><br>


        <input type="submit" name="submit" value="Aanmelden">
        </center>
    </form>


	</body>
</html>
