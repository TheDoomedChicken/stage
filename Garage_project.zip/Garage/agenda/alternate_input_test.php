<!DOCTYPE html>
<html>
	<head>
		<title>Demo</title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	    <meta name="description" content="Demo project">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<style type="text/css"></style>
		<link rel="stylesheet" href="../css/stock_include.css">
		<link href="../css/simple-sidebar.css" rel="stylesheet">
		<?php
		include_once "../bootstrap_include.php";
		?>

	</head>
	<body>



<?php
include_once "sidebar_top_include_agenda.php";
?>
<!--this is where the page content goes-->
<h2>testing</h2>
<div class="advent">
  <form class="testform" method="POST" action="insert.php">
    <input type="date" id="datum" name="datum">
    <input type="submit">
  </form>


</div>

<?php
include_once "sidebar_bottom_include_agenda.php";
?>

	</body>
</html>
