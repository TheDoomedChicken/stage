<!DOCTYPE html>
<html>
	<head>
		<title>No space</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
        <body>
        <center><h1>Er is geen <?php echo $_GET["error"]?></h1></center>
        <a href="Service.php">ga terug naar de service pagina</a>
        </body>
