<?php
$Month = 2592000 + time();
 //this adds 30 days to the current time
 setcookie('visit' , date("F jS - g:i a"), $Month);

 if(isset($_COOKIE['visit']))
 {
 $last = $_COOKIE['visit'];
 }
 ?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="index_admin.php">
    <img src="images/about-logo.png" alt="logo" style="width:40px;">
  </a>
  
  <!-- Links -->
  <ul class="navbar-nav">
      <a class="nav-link" href="Create_admin.php">Create Admin</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="Producten_invoeren.php">Product Invoeren</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="Service_before_overzicht.php">Service afspraak overzicht</a>
    </li>
      <li class="nav-item">
      <a class="nav-link" href="Reparatie_overzicht.php">Reparatie afspraak overzicht</a>
    </li>
       <li class="nav-item">
      <a class="nav-link" href="Product_overzicht.php">Product Stock</a>
    </li>

    <li class="nav-item">
      <a class="nav-link" href="../logout.php">Logout</a>
    </li>
    
  </ul>
</nav>

 <?php echo "<p>ingelogd als admin</p>";
                
                echo "<br>";
                ?>

<?php
echo "<br><p> Welcome back! <br> You last visited on $last</p>";
 ?>

</body>
</html>