<?php
include_once ('../side-job/config.php') ;

$adnaam = mysqli_real_escape_string($conn, $_REQUEST['advoornaam']);
$admail = mysqli_real_escape_string($conn, $_REQUEST['adMail']);
$adwachtwoord = mysqli_real_escape_string($conn, $_REQUEST['adWachtwoord']);

$adhash = password_hash($adwachtwoord, PASSWORD_DEFAULT);



$sql = "INSERT INTO admin (adNaam, adMail, adWachtwoord) VALUES ('$adnaam' , '$admail' , '$adhash' )";
if(mysqli_query($conn, $sql)){
    header("Location: http://localhost/Garage/admin/index_admin.php");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
    echo 'help';
}

mysqli_close($conn);
?>
