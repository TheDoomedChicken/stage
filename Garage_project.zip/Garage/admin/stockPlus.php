<?php
include_once ('../side-job/config.php') ;

$productID = $_GET["id"];
echo $productID;

$query = "SELECT productQuantity FROM product WHERE productID = '".$productID."'";
$result = mysqli_query($conn, $query);
if(mysqli_num_rows($result) > 0){
  while($row = mysqli_fetch_assoc($result)){
    $oud_quantity = $row["productQuantity"];
  }
} else {
  echo "fail";
}
$new_quantity = $oud_quantity + 1;

$sql = "UPDATE product SET productQuantity='".$new_quantity."' WHERE productID = '".$productID."'";
if ($conn -> query($sql))

  header("Location: http://localhost/Garage/admin/Product_overzicht.php");

?>
