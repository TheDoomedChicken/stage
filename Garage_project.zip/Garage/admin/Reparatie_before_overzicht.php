<!DOCTYPE html>
<html>
<head>
	 <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
</head>
<body>
 ?>
<!--this is where the page content goes-->
 <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="index_admin.php">
    <img src="images/about-logo.png" alt="logo" style="width:60px;">
  </a>
  
  <!-- Links -->
  <ul class="navbar-nav">
      <a class="nav-link" href="Create_admin.php">Create Admin</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="Producten_invoeren.php">Product Invoeren</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="Service_before_overzicht.php">Service afspraak overzicht</a>
    </li>
      <li class="nav-item">
      <a class="nav-link" href="Reparatie_before_overzicht.php">Reparatie afspraak overzicht</a>
    </li>
       <li class="nav-item">
      <a class="nav-link" href="Product_overzicht.php">Product Stock</a>
    </li>

    <li class="nav-item">
      <a class="nav-link" href="../logout.php">Logout</a>
    </li>
    
  </ul>
</nav>
<center>
<form method="POST" action="Reparatie_overzicht.php">
<input type="date" id="checkdate" name="checkdate"><br>
<input type="submit" id="submit" value="Check">
</form>
</center>


</body>
</html>