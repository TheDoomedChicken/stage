<?php

/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'garage');

/* Attempt to connect to MySQL database */
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check connection
if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
  <link href="css_overzicht.css" rel="stylesheet">
</head>
<body>
   <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="index_admin.php">
    <img src="images/about-logo.png" alt="logo" style="width:60px;">
  </a>
  
  <!-- Links -->
  <ul class="navbar-nav">
      <a class="nav-link" href="Create_admin.php">Create Admin</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="Producten_Invoeren.php">Product Invoeren</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="Service_before_overzicht.php">Service afspraak overzicht</a>
    </li>
      <li class="nav-item">
      <a class="nav-link" href="Reparatie_before_overzicht.php">Reparatie afspraak overzicht</a>
    </li>
       <li class="nav-item">
      <a class="nav-link" href="Product_overzicht.php">Product Stock</a>
    </li>

    <li class="nav-item">
      <a class="nav-link" href="../logout.php">Logout</a>
    </li>
    
  </ul>
</nav>
</body>
</html>


<?php
$checkdate = $_REQUEST["checkdate"];
echo $checkdate;
$query = "SELECT * FROM afspraak ORDER BY datum ASC";
        $result = mysqli_query($conn,$query);
        if(mysqli_num_rows($result) > 0 ){
            while($row = mysqli_fetch_array($result)){


            }
        }
    ?>


    <div style="clear: both">
    </div>
    <h3 class="title2">Service afspraak</h3>
    <div class="table-responsive">
        <table class="table table-bordered">


            <tr>
                <?php
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT Afspraak_ID, ID, datum, werkuur, ad_ID FROM afspraak WHERE datum = '".$checkdate."' AND soort = 'service'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
         // output data of each row
            while($row = $result->fetch_assoc()) {
                echo "ID: " . $row["Afspraak_ID"]. " - Klant ID: " . $row["ID"]. " - datum: " . $row["datum"]. " - werkuur: ". $row["werkuur"]." - admin ID: " . $row["ad_ID"]." - soort: service"."<br>";
                $idnumber = $row["Afspraak_ID"];





           }
        } else {
            echo "0 results";
        }
$conn->close();
                ?>


            </tr>

        </table>
<!--eine service lijst ========================================================================================================================= -->