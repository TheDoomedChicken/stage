<?php
include_once ('../side-job/config.php') ;

$productnaam = mysqli_real_escape_string($conn, $_REQUEST['productnaam']);
$productprijs = mysqli_real_escape_string($conn, $_REQUEST['productprijs']);
$productIMG = mysqli_real_escape_string($conn, $_REQUEST['productIMG']);
$productQuantity = mysqli_real_escape_string($conn, $_REQUEST['productQuantity']);




$sql = "INSERT INTO product (productNaam, productPrijs, productQuantity, productIMG) VALUES ('$productnaam' , '$productprijs' , '$productQuantity' , '$productIMG' )";
if(mysqli_query($conn, $sql)){
    header("Location: http://localhost/Garage/admin/Producten_invoeren.php");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
    echo 'help';
}

mysqli_close($conn);
?>
